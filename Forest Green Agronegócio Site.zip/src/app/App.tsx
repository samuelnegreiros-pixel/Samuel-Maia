import { Leaf, ArrowRight, TreePine, Sprout, Globe, BarChart3, Mail, Phone, MapPin, Menu, X } from "lucide-react";
import { useState } from "react";

const heroImages = [
  {
    image: "https://images.unsplash.com/photo-1684154739620-ef7b1e078d4d?w=900&h=700&fit=crop&auto=format",
    alt: "Campo de trigo verde sob o sol",
    tag: "Sustentabilidade",
    label: "Agricultura do Futuro",
  },
  {
    image: "https://images.unsplash.com/photo-1599209692026-1d9e12b923bc?w=900&h=700&fit=crop&auto=format",
    alt: "Floresta tropical preservada",
    tag: "Meio Ambiente",
    label: "Preservação Florestal",
  },
  {
    image: "https://images.unsplash.com/photo-1744726010540-bf318d4a691f?w=900&h=700&fit=crop&auto=format",
    alt: "Alfaces cultivadas em fileiras numa fazenda",
    tag: "Orgânico",
    label: "Colheita Orgânica",
  },
];

const services = [
  {
    icon: Sprout,
    title: "Agricultura Regenerativa",
    description: "Práticas que restauram a saúde do solo, aumentam a biodiversidade e sequestram carbono da atmosfera.",
  },
  {
    icon: TreePine,
    title: "Reflorestamento",
    description: "Programas de plantio de árvores nativas que recuperam ecossistemas degradados e criam corredores ecológicos.",
  },
  {
    icon: Globe,
    title: "Rastreabilidade Verde",
    description: "Tecnologia de ponta para rastrear a origem dos produtos e garantir total transparência na cadeia produtiva.",
  },
  {
    icon: BarChart3,
    title: "Créditos de Carbono",
    description: "Consultoria e gestão de projetos REDD+ e projetos agrícolas de baixo carbono com certificação internacional.",
  },
];

const stats = [
  { value: "120K", label: "Hectares Manejados" },
  { value: "38+", label: "Anos de Experiência" },
  { value: "850", label: "Produtores Parceiros" },
  { value: "94%", label: "Redução de Emissões" },
];

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground" style={{ fontFamily: "'DM Sans', sans-serif" }}>

      {/* NAV */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-primary/95 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <a href="#" className="flex items-center gap-2">
            <Leaf size={24} color="#7aad5a" />
            <span
              className="text-primary-foreground tracking-wide"
              style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.35rem", fontWeight: 600 }}
            >
              Forest Green
            </span>
          </a>

          <div className="hidden md:flex items-center gap-8">
            {["Início", "Sobre", "Serviços", "Impacto", "Contato"].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="text-primary-foreground/80 hover:text-accent transition-colors text-sm tracking-wide"
              >
                {item}
              </a>
            ))}
            <a
              href="#contato"
              className="px-5 py-2 bg-accent text-white text-sm rounded hover:bg-accent/85 transition-colors"
            >
              Fale Conosco
            </a>
          </div>

          <button
            className="md:hidden text-primary-foreground"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Menu"
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden bg-primary border-t border-white/10 px-6 py-4 flex flex-col gap-4">
            {["Início", "Sobre", "Serviços", "Impacto", "Contato"].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="text-primary-foreground/80 hover:text-accent transition-colors text-sm"
                onClick={() => setMenuOpen(false)}
              >
                {item}
              </a>
            ))}
          </div>
        )}
      </nav>

      {/* HERO — 3 imagens lado a lado */}
      <section id="início" className="pt-16">
        {/* Cabeçalho do hero */}
        <div
          className="bg-primary px-6 md:px-16 py-16 text-center"
        >
          <span className="inline-block px-3 py-1 bg-accent text-white text-xs tracking-widest uppercase mb-4 rounded-sm">
            Agronegócio Verde
          </span>
          <h1
            className="text-primary-foreground mb-4 mx-auto"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 5vw, 3.6rem)",
              fontWeight: 700,
              lineHeight: 1.15,
              maxWidth: "700px",
            }}
          >
            Cultivamos o futuro com responsabilidade
          </h1>
          <p className="text-primary-foreground/75 mx-auto mb-8 leading-relaxed" style={{ maxWidth: "540px" }}>
            Da floresta à colheita, praticamos um agronegócio que respeita o meio ambiente e cuida das próximas gerações.
          </p>
          <a
            href="#serviços"
            className="inline-flex items-center gap-2 px-7 py-3 bg-accent text-white rounded hover:bg-accent/85 transition-colors"
          >
            Conheça nosso trabalho <ArrowRight size={18} />
          </a>
        </div>

        {/* 3 fotos lado a lado */}
        <div className="grid grid-cols-1 md:grid-cols-3" style={{ height: "clamp(260px, 45vw, 520px)" }}>
          {heroImages.map((img) => (
            <div key={img.label} className="relative overflow-hidden group" style={{ minHeight: "220px" }}>
              <img
                src={img.image}
                alt={img.alt}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <span className="inline-block px-2 py-0.5 bg-accent text-white text-xs tracking-widest uppercase mb-2 rounded-sm">
                  {img.tag}
                </span>
                <p
                  className="text-white"
                  style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.05rem", fontWeight: 600 }}
                >
                  {img.label}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ABOUT */}
      <section id="sobre" className="py-24 px-6 md:px-16 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <span className="text-accent text-sm tracking-widest uppercase">Quem Somos</span>
            <h2
              className="text-foreground mt-3 mb-6"
              style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", fontWeight: 600, lineHeight: 1.2 }}
            >
              Agronegócio que respeita a floresta
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-5">
              A Forest Green nasceu da convicção de que é possível produzir com eficiência sem abrir mão da responsabilidade ambiental. Atuamos em toda a cadeia do agronegócio sustentável — do manejo do solo à comercialização.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Com mais de três décadas de experiência, somos referência em práticas de baixo carbono, integração lavoura-pecuária-floresta (iLPF) e certificações ambientais nacionais e internacionais.
            </p>
            <a href="#serviços" className="inline-flex items-center gap-2 text-accent hover:text-primary transition-colors" style={{ fontWeight: 500 }}>
              Ver nossos serviços <ArrowRight size={16} />
            </a>
          </div>

          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1551649001-7a2482d98d05?w=700&h=800&fit=crop&auto=format"
              alt="Agricultor segurando beterrabas recém-colhidas"
              className="w-full object-cover rounded-sm"
              style={{ height: "480px" }}
            />
            <div className="absolute -bottom-6 -left-6 bg-primary text-primary-foreground px-8 py-6 hidden md:block">
              <p className="text-accent" style={{ fontFamily: "'Playfair Display', serif", fontSize: "2rem", fontWeight: 700 }}>
                38+
              </p>
              <p className="text-primary-foreground/80 text-sm mt-1">
                Anos de experiência<br />em agronegócio verde
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section id="impacto" className="py-20 px-6" style={{ background: "#1e4620" }}>
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {stats.map((stat) => (
            <div key={stat.label} className="py-4">
              <p
                className="text-accent"
                style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.2rem, 4vw, 3rem)", fontWeight: 700 }}
              >
                {stat.value}
              </p>
              <p className="text-primary-foreground/70 text-sm mt-2 tracking-wide">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section id="serviços" className="py-24 px-6 md:px-16 bg-card">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-accent text-sm tracking-widest uppercase">O que Oferecemos</span>
            <h2
              className="text-foreground mt-3"
              style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", fontWeight: 600 }}
            >
              Soluções para um campo mais verde
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((svc) => {
              const Icon = svc.icon;
              return (
                <div
                  key={svc.title}
                  className="group p-7 border border-border rounded-sm hover:border-accent transition-colors bg-background"
                >
                  <div className="w-12 h-12 rounded-sm bg-secondary flex items-center justify-center mb-5 group-hover:bg-accent/15 transition-colors">
                    <Icon size={22} className="text-primary group-hover:text-accent transition-colors" />
                  </div>
                  <h3
                    className="text-foreground mb-3"
                    style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.05rem", fontWeight: 600 }}
                  >
                    {svc.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{svc.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* BANNER */}
      <section className="relative py-28 px-6 overflow-hidden" style={{ background: "#1a2e1a" }}>
        <img
          src="https://images.unsplash.com/photo-1521706862577-47b053587f91?w=1400&h=500&fit=crop&auto=format"
          alt="Floresta exuberante vista de cima"
          className="absolute inset-0 w-full h-full object-cover opacity-20"
        />
        <div className="relative z-10 max-w-3xl mx-auto text-center">
          <h2
            className="text-white mb-5"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", fontWeight: 700 }}
          >
            Juntos por um agronegócio mais justo e sustentável
          </h2>
          <p className="text-white/75 leading-relaxed mb-8 text-base md:text-lg">
            Seja você produtor rural, investidor ou empresa que busca compensar emissões — a Forest Green tem a solução certa para o seu perfil.
          </p>
          <a
            href="#contato"
            className="inline-flex items-center gap-2 px-8 py-4 bg-accent text-white rounded hover:bg-accent/85 transition-colors"
            style={{ fontWeight: 500 }}
          >
            Entre em contato <ArrowRight size={18} />
          </a>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contato" className="py-24 px-6 md:px-16 bg-background">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16">
          <div>
            <span className="text-accent text-sm tracking-widest uppercase">Fale Conosco</span>
            <h2
              className="text-foreground mt-3 mb-6"
              style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(1.8rem, 3vw, 2.4rem)", fontWeight: 600 }}
            >
              Vamos cultivar um futuro melhor juntos
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Nossa equipe está pronta para apresentar as melhores soluções em agronegócio verde para a sua realidade.
            </p>
            <div className="space-y-5">
              {[
                { icon: Phone, label: "(11) 9999-9999" },
                { icon: Mail, label: "contato@forestgreen.com.br" },
                { icon: MapPin, label: "São Bernardo do Campo, SP — Brasil" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-4 text-muted-foreground">
                  <div className="w-10 h-10 rounded-sm bg-secondary flex items-center justify-center shrink-0">
                    <Icon size={18} className="text-primary" />
                  </div>
                  <span className="text-sm">{label}</span>
                </div>
              ))}
            </div>
          </div>

          <form className="space-y-5">
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">Nome</label>
                <input
                  type="text"
                  placeholder="Seu nome"
                  className="w-full px-4 py-3 bg-input-background border border-border rounded-sm text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/40 transition"
                />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">E-mail</label>
                <input
                  type="email"
                  placeholder="seu@email.com"
                  className="w-full px-4 py-3 bg-input-background border border-border rounded-sm text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/40 transition"
                />
              </div>
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-1 block">Assunto</label>
              <input
                type="text"
                placeholder="Como podemos ajudar?"
                className="w-full px-4 py-3 bg-input-background border border-border rounded-sm text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/40 transition"
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-1 block">Mensagem</label>
              <textarea
                rows={5}
                placeholder="Descreva sua necessidade..."
                className="w-full px-4 py-3 bg-input-background border border-border rounded-sm text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/40 transition resize-none"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 bg-primary text-primary-foreground rounded-sm hover:bg-accent transition-colors"
              style={{ fontWeight: 500 }}
            >
              Enviar Mensagem
            </button>
          </form>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-primary py-10 px-6 md:px-16">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Leaf size={20} color="#7aad5a" />
            <span
              className="text-primary-foreground"
              style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: "1.1rem" }}
            >
              Forest Green
            </span>
          </div>
          <p className="text-primary-foreground/50 text-xs text-center">
            © 2026 Forest Green Agronegócio. Todos os direitos reservados.
          </p>
          <div className="flex gap-5">
            {["Privacidade", "Termos", "Sustentabilidade"].map((link) => (
              <a key={link} href="#" className="text-primary-foreground/50 hover:text-accent text-xs transition-colors">
                {link}
              </a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
