
  # Forest Green Agronegócio Site

  This is a code bundle for Forest Green Agronegócio Site. The original project is available at https://www.figma.com/design/52PicyYy5hgIINPrbov90u/Forest-Green-Agroneg%C3%B3cio-Site.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  